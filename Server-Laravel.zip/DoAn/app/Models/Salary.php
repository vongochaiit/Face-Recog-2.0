<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Salary extends Model
{
    protected $table = "salaries";
    protected $guarded = ['id'];//tất cả ngoại trừ id
    protected $timestamp = true;
    //khai báo mối quán hệ 1-1
    public function salary()
    {
    	return $this->belongsTo('App\Models\Position');
    }
}
