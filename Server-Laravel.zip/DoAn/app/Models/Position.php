<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Position extends Model
{
    protected $table = "positions";
    protected $guarded = ['id'];//tất cả ngoại trừ id
    protected $timestamp = true;
    //khai báo mối quán hệ 1-n
    public function Employee()
    {
    	return $this->hasMany('App\Models\Employee');
    }

    public function salary()
    {
        return $this->hasOne('App\Models\Salary');
    }
}
