<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    protected $table = "employees";
    protected $guarded = ['id'];//tất cả ngoại trừ id
    protected $timestamp = true;

    public function Company()
    {
    	return $this->belongsTo('App\Models\Company');
    }

    public function Position()
    {
    	return $this->belongsTo('App\Models\Position');
    }

    public function Image()
    {
        return $this->hasMany('App\Models\Image');
    }

    public function managements(){
        return $this->hasMany('App\Models\Management','employee_id','id');
    }
}
