<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Management extends Model
{
    protected $table = "management";
    
   protected $fillable =['status','intime','outtime','date','employee_id','isDeleted'];
   public function employee()
   {
       return $this->belongsTo('App\Models\Employee','employee_id','id');
   }

}

