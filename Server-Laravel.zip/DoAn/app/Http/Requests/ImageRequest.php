<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ImageRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'imageFile' => 'required',
            'imageFile.*' => 'mimes:jpeg,png,jpg,gif,svg',
            'employee_id' =>'required'
        ];
    }

    public function messages()
    {
        return [
            'imageFile.required'=>'Ảnh không được rỗng!',
            'imageFile.*.mimes'=>'file phải đúng định dạng(jpg,jpeg,png,gif,svg)!',
            'imageFile.*.max'=>'Size Ảnh không được quá 2048KB!',
            'employee_id.required'=>'Nhân Viên không được rỗng!'
        ];
    }
}
