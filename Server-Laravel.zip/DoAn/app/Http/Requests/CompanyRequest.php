<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CompanyRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'companies_code'=>'required|min:5|max:10|unique:companies',
            'name'=>'required|max:20',
            'address'=>'required',
            'email'=>'required|email'
        ];
    }

    public function messages()
    {
        return [
            'companies_code.unique'=>'ID công ty  này đã được sử dụng',
            'companies_code.required'=>'Mã công ty không được rỗng!',
            'companies_code.min'=>'Mã công ty tối thiểu 5 ký tự!',
            'companies_code.max'=>'Mã công ty tối đa 10 ký tự!',
            'name.required'=>'Tên Công ty không được rỗng!',
            'name.max'=>'Tên Công ty tối đa 20 ký tự!',
            'address.required'=>'Địa chỉ công ty không được rỗng!',
            'email.required'=>'Email không được rỗng!',
            'email.email'=>'Email không đúng định dạng Ex:(abc@gmail.com)!',
            
        ];
    }
}
