<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PositionRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'position_code'=>'required|min:5|max:10|unique:positions',
            'name'=>'required|max:20',
            'luongcoban'=>'required|numeric',
            'hesoluong'=>'required|numeric',
            'luongnhan'=>'required|numeric'
        ];
    }

    public function messages()
    {
        return [
            'position_code.unique'=>'Mã Chức vụ không được giống nhau !',
            'position_code.required'=>'ID Chức Vụ không được rỗng!',
            'position_code.min'=>'ID Chức Vụ tối thiểu 5 ký tự!',
            'position_code.max'=>'ID Chức Vụ tối đa 10 ký tự!',
            'name.required'=>'Tên Chức Vụ không được rỗng!',
            'name.max'=>'Tên Chức Vụ tối đa 20 ký tự!',
            'luongcoban.required'=>'Lương Cơ Bản không được rỗng!',
            'luongcoban.numeric'=>'Lương Cơ Bản Phải là kiểu số!',
            'hesoluong.required'=>'Hệ Số Lương không được rỗng!',
            'hesoluong.numeric'=>'Hệ Số Lương Phải là kiểu số!',
            'luongnhan.required'=>'Lương Nhận không được rỗng!',
            'luongnhan.numeric'=>'Lương Nhận Phải là kiểu số!'
            
        ];
    }
}
