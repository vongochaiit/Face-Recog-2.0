<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class EmployeeRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'employee_code'=>'required|min:5|max:10|unique:employees',
            'name'=>'required|max:20',
            'birthday'=>'required',
            'phone_number'=>'required|numeric|regex:/(0)[0-9]{9}/',
            'image'=>'required|mimes:jpeg,png,jpg,gif',
            'address'=>'required',
            'company_id'=>'required',
            'position_id'=>'required'

        ];
    }

    public function messages()
    {
        return [
            'employee_code.unique'=>'ID nhân viên  này đã được sử dụng',
            'employee_code.required'=>'ID Nhân Viên không được rỗng',
            'employee_code.min'=>'ID Nhân Viên tối thiểu 5 ký tự ',
            'employee_code.max'=>'ID Nhân Viên tối tối đa là 10 ký tự',
            'name.required'=>'Tên Nhân Viên không được rỗng',
            'name.max:20'=>'Tên Nhân Viên tối đa 20 ký tự',
            'birthday.required'=>'Ngày sinh không được rỗng',
            'image.required'=>'Avatar không được rỗng',
            'image.mimes'=>'file phải đúng định dạng(jpg,jpeg,png,gif,svg)!',
            'image.max'=>'Avatar không được quá 2048KB!',
            'phone_number.required'=>'Số Điện Thoại không được rỗng',
            'phone_number.numeric'=>'Số Điện Thoại phải là kiểu số',
            'phone_number.regex'=>'Số Điện Thoại phải bắt đầu bằng số 0 và tối thiểu 10 số!',
            'address.required'=>'Địa chỉ không được rỗng',
            'company_id.required'=>'Công ty không được rỗng',
            'position_id.required'=>'Chức Vụ không được rỗng'
            
        ];
    }
}
