<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\ImageRequest;
use\App\Models\Employee;
use\App\Models\Image;
use\DB;
use Carbon\Carbon;

class ImageController extends Controller
{

    public function index()
    {
        $images = Image::with('Employee')->get();
        return view('admin.images.index',compact('images'));
    }


    public function create()
    {
        $employees = Employee::pluck('name','id')->toArray();
        return view('admin.images.create', compact('employees'));
    }


    public function store(ImageRequest $request)
    {      
        $request->validated();
        if($request->hasFile('imageFile')){

            $image_array = $request->file('imageFile');
            $array_len = count($image_array);

            for($i=0;$i<$array_len;$i++){
                
                $image_ext = $image_array[$i]->getClientOriginalExtension();
                $new_image_name = rand(123456,999999).".".$image_ext;
                $destination_path = public_path('images');
                $image_array[$i]->move($destination_path,$new_image_name);
                $images = new Image([
                  'name' => $new_image_name,
                  'image_path' => $destination_path,
                  'employee_id' => $request->employee_id,
                  'isDeleted'=> true
                ]);
                
                $images->save();
            }
            return redirect('/image-upload')->with("success", "Upload Ảnh Thành Công!");      
        }else{
            return back()->with("errors", "Upload Ảnh Thất Bại!");
        }
    }

    public function getImages(){
       
        $image = DB::table('images')->get();
        return response()->json($image);
    }

    public function show($id)
    {
        //
    }

    public function edit($id)
    {
        $image = Image::findOrfail($id);
        $employees = Employee::pluck('name','id')->toArray();
        return view('admin.images.edit',compact('image','employees'));
    }

    public function update(Request $request, $id)
    {
        //dd($request);
        $this->validate($request, [
        'imageFile' => 'required|max:2048',
        'imageFile.*' => 'mimes:jpg,jpeg,png,gif'
      ]);
        if($request->hasFile('imageFile')){
            $image_array = $request->file('imageFile');
            $array_len = count($image_array);

            for($i=0;$i<$array_len;$i++){
                $image_ext = $image_array[$i]->getClientOriginalExtension();
                $new_image_name = rand(123456,999999).".".$image_ext;
                $destination_path = public_path('images');
                $image_array[$i]->move($destination_path,$new_image_name);

                $image = Image::findOrfail($id);
                $image->name = $new_image_name;
                $image->image_path = $destination_path;
                $image->employee_id = $request->employee_id;
                $image->updated_at = Carbon::now()->toDateTimeString();

                $image->update();
            }    
            return redirect('/image-upload')->with("success", "Update Ảnh Thành Công!");      
        }else{

            return redirect('/image-upload')->with("error", "Upload Ảnh Thất Bại!");
        }
    }

    public function destroy($id)
    {
        $image = Image::findOrfail($id);
        if ($image) {
            $image->delete();
            return redirect('/image-upload')->with("success", "Xóa Ảnh Thành Công!");
        }else{
            return back()->with("errors", "Xóa Ảnh Thất Bại!");
        }
        
    }

    public function deleteAll(Request $request)
    {
        $ids = $request->input('ids');
        Image::whereIn('id', $ids)->delete();
        return back()->with("success", "Xóa Ảnh Thành Công!");
    }
}
