<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\CompanyRequest;
use App\Models\Company;
use App\Models\Employee;
//gọi carbon
use Carbon\Carbon;

class CompanyController extends Controller
{
    public function index()
    {
        $companies = Company::all();
        return view('admin.companies.index', compact('companies'));
    }

    public function create()
    {
        return view('admin.companies.create');
    }

    public function store(CompanyRequest $request)
    {
        $request->validated();
        $company_data = new Company([

            'companies_code' => $request->companies_code,
            'name' => $request->name,
            'address' => $request->address,
            'email' => $request->email,
            'isDeleted'=> true
        ]);
            $company_data->save();
        if($company_data){

            return redirect('/companies')->with("success", "Tạo dữ liệu thành công!");      
        }else{

            return back()->with("errors", "Tạo dữ liệu Thất Bại!");
        }
    }

    public function show($id)
    {
        // $company = Company::findOrfail($id);
        // return view('admin.companies.show',compact('company'));
    }

    public function edit($id)
    {
        $company = Company::findOrfail($id);
        return view('admin.companies.edit',compact('company'));
    }

    public function update(Request $request, $id)
    {
        $company = Company::findOrfail($id);
        if($company){
            $company->companies_code = $request->companies_code;
            $company->name = $request->name;
            $company->address = $request->address;
            $company->email = $request->email;
            $company->updated_at = Carbon::now()->toDateTimeString();

            $company->update();
        }else{

            return back()->with("errors", "Cập Nhật dữ liệu Thất Bại!");
        }
            return redirect('/companies')->with("success", "Cập Nhật dữ liệu thành công!");
    }

    public function destroy($id)
    {
        $company = Company::findOrFail($id);
        $employees = Employee::all();
        $count = '';
        foreach ($employees as  $employee) {
            if ($employee->company_id == $id) {
                $count = 'found';
            }
        }
        //2. xóa đối tượng
        if($count == 'found'){
            \Session::flash('error', 'Không Được Phép Xóa Ràng Buộc Khóa Ngoại!');
             return redirect('/companies');
        }else{
            $company->delete();
             \Session::flash('success', 'Xóa Thành Công!');
             return redirect('/companies');
        }
    }
}
