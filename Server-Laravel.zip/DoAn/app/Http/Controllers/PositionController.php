<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\PositionRequest;
use App\Models\Position;
use App\Models\Salary;
use App\Models\Employee;
//gọi carbon
use Carbon\Carbon;

class PositionController extends Controller
{
    public function index()
    {
        $positions = Position::with('salary')->latest()->get();
        return view('admin.positions.index',compact('positions'));
    }

    public function create()
    {
        
        return view('admin.positions.create');
    }

    public function store(PositionRequest $request)
    {
        $request->validated();
        $position_id = Position::insertGetId([
            'position_code' => $request->position_code,
            'name' => $request->name,
            'isDeleted'=> true
        ]);
        $position_data = Position::findOrfail($position_id);

        $salary_data = new Salary([
            'luongcoban' => $request->luongcoban,
            'hesoluong' => $request->hesoluong,
            'luongnhan'=> $request->luongnhan,
            'position_id' => $position_id,
            'isDeleted'=> true
        ]);
        $position_data->salary()->save($salary_data);
        
        if($position_data){

            return redirect('/positions')->with("success", "Tạo dữ liệu thành công!");      
        }else{

            return back()->with("errors", "Tạo dữ liệu Thất Bại!");
        }
    }

    public function show($id)
    {
       
    }

    public function edit($id)
    {
        $position = Position::with('salary')->findOrFail($id);
        
        return view('admin.positions.edit',compact('position'));
    }

    public function update(Request $request, $id)
    {
        $position = Position::findOrfail($id);
        if($position){
            $position->position_code = $request->position_code;
            $position->name = $request->name;
            $position->updated_at = Carbon::now()->toDateTimeString();

            $position->update();
        }
        $position->salary->luongcoban = $request->luongcoban;
        $position->salary->hesoluong = $request->hesoluong;
        $position->salary->luongnhan = $request->luongnhan;

        $position->salary->update();
        if($position){

            return redirect('/positions')->with("success", "Cập Nhật dữ liệu thành công!");      
        }else{

            return back()->with("errors", "Cập Nhật dữ liệu Thất Bại!");
        }    
    }

    public function destroy($id)
    {
        $position = Position::findOrFail($id);
        $employees = Employee::all();
        $count = '';
        foreach ($employees as  $employee) {
            if ($employee->position_id == $id) {
                $count = 'found';
            }
        }
        //2. xóa đối tượng
        if($count == 'found'){
            \Session::flash('error', 'Không Được Phép Xóa Ràng Buộc Khóa Ngoại!');
             return redirect('/positions');
        }else{
            $position->delete();
             \Session::flash('success', 'Xóa Thành Công!');
             return redirect('/positions');
        }
    }
}
