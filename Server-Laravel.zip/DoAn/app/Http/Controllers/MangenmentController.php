<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\ImageRequest;
use\App\Models\Employee;
use\App\Models\Management;
use\DB;
use Carbon\Carbon;
use Session;


class MangenmentController extends Controller
{
    // search employees to word by date
    public function searchByDate(Request $request)
    {
        $today = today(); 
        $dates = []; 
        for($i=1; $i < $today->daysInMonth + 1; ++$i) {
            $dates[] = \Carbon\Carbon::createFromDate($today->year, $today->month, $i)->format('Y-m-d');
        }
        if(!$request->date){
            $date = Carbon::now('Asia/Ho_Chi_Minh')->toDateString();  
        }else{
            $date = $request->date;
        }   
        $employee = new Employee();
        $employees = $employee->select()->whereHas('managements', function ($query) use ($date) {
             $query->whereDate('date', $date);
            })->with(['managements' => function ($query) use ($date){
                $query->whereDate('date', $date);
             }])->get();
      
            return view('admin.management.list_by_date')->with([
             'employees' => $employees,
             'date' => $date,
             'today' => $today,
             'dates' => $dates
         ]);
    }

    public function searchAll(Request $request)
    {   
        $today = today(); 
        $dates = []; 
        for($i=1; $i < $today->daysInMonth + 1; ++$i) {
            $dates[] = \Carbon\Carbon::createFromDate($today->year, $today->month, $i)->format('Y-m-d');
        }

        if(!$request->date){
            $date = Carbon::now('Asia/Ho_Chi_Minh')->toDateString();
        }else{
            $date = $request->date;
        }   
        $employee = new Employee();
        $employees = $employee->select()->with(['managements' => function ($query) use ($date){
            $query->whereDate('date', $date);
        }])->get();

        return view('admin.management.list')->with([
            'employees' => $employees,
            'date' => $date,
            'today' => $today,
            'dates' => $dates
         ]);
        
    }
    public function getView(Request $request){
        $date = Carbon::now('Asia/Ho_Chi_Minh')->toDateString();
        $today = today(); 
        $dates = []; 
        for($i=1; $i < $today->daysInMonth + 1; ++$i) {
            $dates[] = \Carbon\Carbon::createFromDate($today->year, $today->month, $i)->format('Y-m-d');
        }
        return view('admin.management.index',compact('today','dates','date'));

    }

    public function showEmployee(){
    
        $date =  Carbon::now('Asia/Ho_Chi_Minh')->toDateString();
        $employee = new Employee();
        $employees = $employee->select()->whereHas('managements', function ($query) use ($date) {
             $query->whereDate('date', $date);
         })->with(['managements' => function ($query) use ($date){
            $query->whereDate('date', $date);
         }])
         ->get();
         return response()->json($employees);



    }
   public function getEmployees(Request $request){

    $params = $request->all();
    $management = new Management();
    $employee = $management->where('employee_id',$params['employee_id'])->whereDate('date',Carbon::now('Asia/Ho_Chi_Minh')->toDateString())->first();

    if(!$employee){
        $management->intime =  Carbon::now('Asia/Ho_Chi_Minh')->toTimeString();
        $management->date = Carbon::now('Asia/Ho_Chi_Minh')->toDateString(); 
        $management->employee_id = $params['employee_id'];
        $management->save();
    }
    $data = $management->where('employee_id',$params['employee_id'])->first();
    $employee = $data->employee;

    return response()->json($employee);
   }

   public function listEmployeeToWorks(){

    $date = Carbon::now('Asia/Ho_Chi_Minh')->toDateString();
    $today = today(); 
    $dates = []; 
        for($i=1; $i < $today->daysInMonth + 1; ++$i) {
            $dates[] = \Carbon\Carbon::createFromDate($today->year, $today->month, $i)->format('Y-m-d');
        }
       $employee = new Employee();
       $employees = $employee->select()->with(['managements' => function ($query) {
            $query->whereDate('date', Carbon::now('Asia/Ho_Chi_Minh')->toDateString());
        }])->get();

        return view('admin.management.list')->with([
            'employees' => $employees,
            'date' => $date,
            'today' => $today,
            'dates' => $dates
            ]);
   }

   public function dateDetails($id){

        $employees = Employee::findOrFail($id);
        $startDate = Management::orderBy('id','asc')->where('employee_id',$id)->first();
        $endDate =  Management::orderBy('id','desc')->where('employee_id',$id)->first();
        $dateworks = Management::where('employee_id',$id)->get();
        return view('admin.management.detail', compact('employees','dateworks','startDate','endDate'));
   }

   public function tinhluong(Request $request){
      
       $date = Management::where('employee_id', $request->id)->where('date','>=',$request->from)->where('date','<=',$request->to)->get();
        $total = $date->count();
        $employee = Employee::findOrfail($request->id);
        return view('admin.management.tinhluong',compact('employee','total'));
    }
}
