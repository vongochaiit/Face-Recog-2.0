<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\EmployeeRequest;
use\App\Models\Employee;
use\App\Models\Company;
use\App\Models\Position;
use\App\Models\Salary;
use\App\Models\Image;
use\App\Models\Management;
use\DB;

use Carbon\Carbon;


class EmployeeController extends Controller
{

    public function index()
    {
    

        // $reserve = Management::all()->where('employee_id')->count();
       
        //dd($count);
            

         
        $employees = Employee::with('Company','Position')->get();
        
        return view('admin.employees.index',compact('employees'));
    }

    public function create()
    {
        $companies = Company::pluck('name','id')->toArray();
        $positions = Position::pluck('name','id')->toArray();
        return view('admin.employees.create',compact('companies','positions'));
    }

    public function EmployeeImage($id){
        $employees = Employee::all();
        $images = Image::where('employee_id',$id)->get();
        return view('admin.employees.employee_image', compact('employees','images'));
    }
    
    // public function tinhluong(Request $request){
      
    //    $date = Management::where('employee_id', $request->id)->where('date','>=',$request->from)->where('date','<=',$request->to)->get();
    //     $total = $date->count();
    //     $employee = Employee::findOrfail($request->id);
    //     return view('admin.employees.tinhluong',compact('employee','total'));
    // }

    public function store(EmployeeRequest $request)
    {
        $validated = $request->validated();
        if($request->hasFile('image')){
            $image_name = $request->file('image')->getClientOriginalName();
            $image_path =$request->image->storeAs('images',$image_name,'public');
            $employees = new Employee([
            'employee_code' => $request->employee_code,
            'name' => $request->name,
            'gender' => $request->gender,
            'birthday' => $request->birthday,
            'avatar' => $image_name,
            'address' => $request->address,
            'phone_number' => $request->phone_number,
            'company_id' => $request->company_id,
            'position_id' => $request->position_id,
            'isDeleted' => true
        ]);

            $employees->save();
        if($employees){

            return redirect('employees')->with("success", "Tạo dữ liệu thành công!");      
        }else{

            return back()->with("errors", "Tạo dữ liệu Thất Bại!");
        }

      }  
    }

    public function show($id)
    {
        $employees = Employee::with('Company','Position')->get();
        $employees = Employee::findOrFail($id);

        
        return view('admin.employees.show',compact('employees','startDate','endDate'));
    }

    public function edit($id)
    {
        $employee = Employee::findOrfail($id);
        $companies = Company::pluck('name','id')->toArray();
        $positions = Position::pluck('name','id')->toArray();
        
        return view('admin.employees.edit',compact('employee','companies','positions'));
    }

    public function update(Request $request, $id)
    {

        $employee = Employee::find($id);
        if($employee){
        $employee->employee_code = $request->employee_code;
        $employee->name = $request->name;
        $employee->gender = $request->gender;
        $employee->birthday = $request->birthday;
        $employee->address = $request->address;
        $employee->phone_number = $request->phone_number;
        $employee->company_id = $request->company_id;
        $employee->position_id = $request->position_id;
        $employee->updated_at = Carbon::now()->toDateTimeString();

        if($request->hasFile('image')){
            $image_name = $request->file('image')->getClientOriginalName();
            $image_path =$request->image->storeAs('images',$image_name,'public');
            $employee->avatar = $image_name;  
        }
        $employee->update();
        }
        else{
            return back()->with("errors", "Cập Nhật dữ liệu Thất Bại!");
        }
        return redirect('/employees')->with("success", "Cập Nhật dữ liệu thành công!");
    
}

    public function destroy($id)
    {
        
        $employee = Employee::findOrfail($id);
        $images = Image::all();
        $count = '';
        foreach ($images as  $images) {
            if ($images->employee_id == $id) {
                $count = 'found';
            }
        }
        //2. xóa đối tượng
        if($count == 'found'){
            \Session::flash('error', 'Không Được Phép Xóa Ràng Buộc Khóa Ngoại!');
             return redirect('/employees');
        }else{
            $employee->delete();
             \Session::flash('success', 'Xóa Thành Công!');
             return redirect('/employees');
        }
    }
}
