<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Salary;
use App\Models\Employee;
//gọi carbon
use Carbon\Carbon;

class SalaryController extends Controller
{
    
    public function index()
    {
        $salaries = Salary::all();
        return view('admin.salaries.index',compact('salaries'));
    }


    public function create()
    {
        return view('admin.salaries.create');
    }
    

    public function store(Request $request)
    {
        $salary_data = new Salary([
            'luong_cb' => $request->luong_cb,
            'hs_luong' => $request->hs_luong,
            'luong_nhan'=> $request->luong_nhan,
            'isdeleted'=> true
        ]);
        $salary_data->save();
        return redirect('/salaries');
    }

    public function show($id)
    {
        $salary = Salary::findOrFail($id);
        return view('admin.salaries.show',compact('salary'));
    }

    public function edit($id)
    {
        $salary = Salary::findOrFail($id);
        return view('admin.salaries.edit',compact('salary'));
    }

    public function update(Request $request, $id)
    {
        $salary = Salary::findOrFail($id);
        if ($salary) {
            $salary->luong_cb = $request->luong_cb;
            $salary->hs_luong = $request->hs_luong;
            $salary->luong_nhan = $request->luong_nhan;

            $salary->update();
        }else{
            return back();
        }
        return redirect('/salaries');

    }

    public function destroy($id)
    {
        $salary = Salary::findOrFail($id);
        $employees = Employee::all();
        $count = '';
        foreach ($employees as  $employee) {
            if ($employee->salaries_id == $id) {
                $count = 'found';
            }
        }
        //2. xóa đối tượng
        if($count == 'found'){
            \Session::flash('error', 'Không Được Phép Xóa Ràng Buộc Khóa Ngoại!');
             return redirect('/salaries');
        }else{
            $salary->delete();
             \Session::flash('success', 'Xóa Thành Công!');
             return redirect('/salaries');
        }
    }
}
