<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSalariesTable extends Migration
{
    public function up()
    {
        Schema::create('salaries', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->double('luongcoban');
            $table->double('hesoluong');
            $table->double('luongnhan');

            $table->bigInteger('position_id')->unsigned();
            $table->foreign('position_id')->references('id')->on('positions')
                ->onUpdate('cascade')
                ->onDelete('cascade');
                
            $table->boolean('isDeleted');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('salaries');
    }
}
