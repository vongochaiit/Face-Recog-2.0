<?php

use Illuminate\Support\Facades\Route;


Route::get('/', function () {
    return view('welcome');
});
Route::get('/home', function () {
    return view('admin.home.index');
});

Route::resource('companies','CompanyController');
Route::resource('positions','PositionController');
Route::resource('salaries','SalaryController');
Route::resource('employees','EmployeeController');
Route::resource('image-upload','ImageController');
Route::get('/attendance','MangenmentController@getView');
Route::get('/listEmployeeToWorks','MangenmentController@listEmployeeToWorks');
Route::get('/searchByDate','MangenmentController@searchByDate')->name('search');
Route::get('/searchAll','MangenmentController@searchAll')->name('searchAll');
Route::get('employeeImage/{id}','EmployeeController@EmployeeImage')->name('EmployeeImage');
Route::delete('/imageDeleteAll', 'ImageController@deleteAll');
Route::get('/dateDetails/{id}','MangenmentController@dateDetails')->name('dateDetails');
//api
Route::get('getImages','ImageController@getImages');
Route::post('tinhluong', 'MangenmentController@tinhluong')->name('tinhluong');
Route::get('/login', 'MainController@index');
Route::post('/checklogin', 'MainController@checklogin');
Route::get('/successlogin', 'MainController@successlogin');
Route::get('/logout', 'MainController@logout');


