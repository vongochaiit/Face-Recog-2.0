<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });
// Route::post('/management','MangenmentController@create');

Route::get('api/packages/get', 'PackagesController@get')->name('get_packages');

Route::post('/getEmployees','MangenmentController@getEmployees');
// Route::get('/test','MangenmentController@getView');
Route::get('/showEmployee','MangenmentController@showEmployee');

Route::get('/listEmployeeByDate','MangenmentController@listEmployeeByDate')->name('listEmployeeByDate');

Route::get('/listEmployeeToWorks','MangenmentController@listEmployeeToWorks');
Route::get('api/packages/get', 'PackagesController@get')->name('get_packages');