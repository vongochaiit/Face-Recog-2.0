@extends('admin.layouts.main')
@section('title','Danh sách company')
@section('content')
 <div class="container-fluid">
 	<div class="card shadow mb-4">
        <div class="card-header py-3">
          <h3 class="m-0 font-weight-bold text-gray-dark">company Detail</h3>
        </div>
        <div class="card-body">

          <div class="table-responsive">
			       <br>
                <div class="col-3">
                  <p>Mã Công Ty: {{ $company->companies_code}}</p>
                </div>

                <div class="col-3">
                  <p>Tên công ty: {{ $company->name}}</p>
                </div>

                <div class="col-3">
                  <p>Địa chỉ: {{ $company->address}}</p>
                </div>

                <div class="col-4">
                  <p>Email: {{ $company->email}}</p>
                </div>
                
                <a style="margin-left: 15px" href="{{ route('companies.index')}}" class="btn btn-primary">Back</a>
            
          </div>
        </div>
    </div>
 </div>

@endsection
@section('script')
@include('admin.shared.script')
@endsection