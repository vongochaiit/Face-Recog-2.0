@extends('admin.layouts.main')
@section('title','Upload Images')
@section('content')
 <div class="row">
  <div class="col-lg-12">

    <div class="sparkline12-list shadow-reset mg-t-30">
        <div class="sparkline12-hd">
            <div class="main-sparkline12-hd">
                <h1 style="font-weight: bold;">Tạo Ảnh Mới <i class="fa big-icon fa-image"></i></h1>
                <div class="sparkline12-outline-icon">
                    <span class="sparkline12-collapse-link"><i class="fa fa-chevron-up"></i></span>
                    <span><i class="fa fa-wrench"></i></span>
                    <span class="sparkline12-collapse-close"><i class="fa fa-times"></i></span>
                </div>
            </div>
        </div>
        <div class="sparkline12-graph">
          <div class="basic-login-form-ad">
              <div class="row">
                  <div class="col-lg-12">
                      <div class="all-form-element-inner">
                          {{ Form::open([ 'url'=>'image-upload','method'=>'post','enctype'=>"multipart/form-data"])}}
                          @csrf
                            <div class="col-4">
                              
                            <div class=" col-lg-12 row">
                            <div class="col-lg-6">
                              <div class="user-image mb-3 text-center">
                                  <div class="imgPreview"> </div>
                              </div> 
                              <div class="form-group-inner">
                                <div class="row">
                                  <div class="col-lg-3">
                                      <label class="login2 pull-right pull-right-pro" for="images">Chọn Ảnh</label>
                                  </div>
                                  <div class="col-lg-8">
                                    <input type="file" name="imageFile[]" class="custom-file-input" id="images" multiple="multiple">
                                    <span class="text-danger">{{$errors->first('imageFile') }}</span>
                                    <span class="text-danger">{{$errors->first('imageFile.*') }}</span>
                                  </div>
                                </div>
                              </div>

                            <div class="form-group-inner">
                              <div class="row">
                                <div class="col-lg-3">
                                    <label class="login2 pull-right pull-right-pro">Nhân Viên</label>
                                </div>
                                <div class="col-lg-8">
                                  {{ Form::select('employee_id',$employees,null,['class'=>'form-control ','id'=>'employees','placeholder'=>'Chọn Nhân Viên'])}}
                                  <span class="text-danger">{{$errors->first('employee_id') }}</span>
                                </div>
                              </div> 
                            </div>
                          </div>
                        </div>
                      </div>

                      <div class="form-group-inner">
                        <div class="login-btn-inner">
                          <div class="row">
                            <div class="col-lg-3"></div>
                            <div class="col-lg-9">
                                <div class="login-horizental cancel-wp pull-left">
                                  <a href="{{ route('image-upload.index')}}" class="btn btn-default">Trở Lại</a>
                                  {{Form::submit('Lưu',["class"=> "btn btn-sm btn-primary login-submit-cs"])}}
                                </div>
                            </div>
                          </div>                    
                        </div>
                      </div>
                    {{ Form::close()}}

                      </div>
                  </div>
              </div>
          </div>
      </div>
    </div>
  </div>
 </div>
 
 <style>
    input[type="file"] {
      display: block;
    }
    .imageThumb {
      max-height: 75px;
      border: 2px solid;
      padding: 1px;
      cursor: pointer;
    }
    .pip {
      display: inline-block;
      margin: 10px 10px 0 0;
    }
    .remove {
      display: block;
      background: #444;
      border: 1px solid black;
      color: white;
      text-align: center;
      cursor: pointer;
    }
    .remove:hover {
      background: white;
      color: black;
}
    </style>

@endsection
@section('script')
@include('admin.shared.script')
@endsection