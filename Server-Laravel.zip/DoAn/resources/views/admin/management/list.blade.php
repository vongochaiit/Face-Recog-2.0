@extends('admin.layouts.main')
@section('title','Danh sách employeeToWork')
@section('content')
<div class="data-table-area mg-b-15">
  <div class="container-fluid">
      @if(Session::has('error'))
        <p class="alert {{ Session::get('alert-class', 'alert-danger') }}">{{ Session::get('error') }}</p>
        @elseif(Session::has('success'))
        <p class="alert {{ Session::get('alert-class', 'alert-success') }}">{{ Session::get('success') }}</p>
      @endif
      <div class="row">
          <div class="col-lg-12">
              <div class="sparkline13-list shadow-reset">
                  <div class="sparkline13-hd">
                      <div class="main-sparkline13-hd">
                          <h1 style="font-weight: bold;">Ngày Đi Làm <i class="fa big-icon fa-calendar"></i></h1>
                          <div class="row">
                                    <div class="col-lg-8" >
                                    
                                  </div> 
                                </div>
                          <div class="sparkline13-outline-icon">
                              <form action="{{ route('searchAll') }}" method="get">
                                      <div class="form-group-inner">
                                  <div class=" row">
                                    <div class="col-lg-8 date" >
                                        <select style="background: #6ce856; margin-left: 15px;" class="form-control" name="date" >
                                          
                                          @foreach($dates as $day)
                                            <option  value="{{$day}}" 
                                              @if($date == $day)
                                              selected
                                              @endif>{{$day}}                                          
                                            </option>
                                            @endforeach
                                          </select>
                                    </div>
                                    <div class="col-lg-2 search" >
                                        <button class="btn btn-info" type="submit" id="search">Search</button>
                                    </div>
                                  </div> 
                                </div>
                                </form>
                          </div>
                          
                      </div>
                  </div>
                  <div class="sparkline13-graph">
                      <div class="datatable-dashv1-list custom-datatable-overright">
                        
                          <table id="table" data-toggle="table" data-pagination="true" data-search="true" data-show-columns="true" data-show-pagination-switch="true" data-show-refresh="true" data-key-events="true" data-show-toggle="true" data-resizable="true" data-cookie="true" data-cookie-id-table="saveId" data-show-export="true" data-click-to-select="true" data-toolbar="#toolbar">
                              <thead>
                                  <tr>
                                      
                                      <th>STT</th>
                                      <th>Tên Nhân Viên</th>
                                      <th>ID</th>
                                      <th>Trạng Thái</th>
                                      <th>Giờ Vào</th>
                                      <th>Ngày Đi Làm</th>
                                      <th>Action</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  @foreach($employees as $key => $value)
                                    <tr>
                                        
                                        <td > {{++$key}} </td>
                                        <td>{{$value->name }}</td>
                                        <td>{{$value->employee_code }}</td>
                                        @if (count($value->managements) > 0)
                                        <td> <p style="color: green">P</p> </td>
                                        @elseif (count($value->managements) == 0) 
                                        <td> <p style="color: red">A</p> </td>
                                        @endif
                                        <td>{{
                                          (count($value->managements)!=0) ? $value->managements[0]->intime : 'Null'
                                        }}</td>
                                        <td>{{
                                          (count($value->managements)!=0) ? $value->managements[0]->date : 'Null'
                                        }}</td>
                                        <td>
                                          <a class="btn-link btn" 
                                               href="{{route('dateDetails',$value->id)}}">
                                               <i style="color: #05b5fa" class="fa big-icon fa-eye"></i>
                                            </a>
                                        </td>
                                     
                                    </tr>
                                    @endforeach
                                  </tbody>
                          </table>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
</div>

<style type="text/css">
  .date{
      float: left;
    }
    .search{
      float: left;
    }
    @media screen and (max-width: 400px) {
     .col-lg-8, .col-lg-2 {
    width: 100%; /* The width is 100%, when the viewport is 800px or smaller */
  }
</style>
@endsection
@section('script')
@include('admin.shared.script')
@endsection