@extends('admin.layouts.main')
@section('title','Danh sách images')
@section('content')

<div class="data-table-area mg-b-15">
  <div class="container-fluid">
    @if(Session::has('error'))
    <p class="alert {{ Session::get('alert-class', 'alert-danger') }}">{{ Session::get('error') }}</p>
    @elseif(Session::has('success'))
    <p class="alert {{ Session::get('alert-class', 'alert-success') }}">{{ Session::get('success') }}</p>
    @endif
      <div class="row">
          <div class="col-lg-12">
              <div class="sparkline13-list shadow-reset">
                  <div class="sparkline13-hd">
                      <div class="main-sparkline13-hd">
                          <h1 style="font-weight: bold;">Điểm Danh</h1>
                          <div class="sparkline13-outline-icon">
                            <form action="{{ route('search') }}" method="get">
                              <div class="form-group-inner">
                                  <div class="row">
                                    <div class="col-lg-8" >
                                        <select style="background: #6ce856; margin-left: 15px;" class="form-control" name="date" >

                                            @foreach($dates as $day)
                                            <option  value="{{$day}}" 
                                              @if($date == $day)
                                              selected
                                              @endif>{{$day}}
                                            </option>
                                            @endforeach
                                          </select>
                                    </div>
                                    <div class="col-lg-2" >
                                        <button class="btn btn-info" type="submit" id="search">Search</button>
                                    </div>
                                  </div> 
                                </div>
                            </form>
                          </div>
                      </div>
                  </div>
                  <div class="container">
                  @foreach ($employees as $key => $item)
                  <div class= "col-md-2 ">
                    <img class="img-thumbnail" src="http://laravelapi.ddns.net/storage/images/{{ $item->avatar }}" />
                    <h5>{{ $item->name }}</h5>
                    <p class="card-text">ID : {{ $item->employee_code }} </p>
                    <p style="background: #6ce856">Intime: {{ $item->managements[0]->intime }}</p>

                    </div>
                    @endforeach
                  </div>
                  
              </div>
          </div>
      </div>
  </div>
</div>



<style>
    .container{
      width: 100%;
    }
    .img-thumbnail{
        width:180px;
        height:180px;
    }
    .col-md-2{
      padding-top: 30px;
      text-align: center;


    }
    h5{
      margin-top: 15px;
      font-weight: bold;

    }
</style>


@endsection
@section('script')
@endsection


