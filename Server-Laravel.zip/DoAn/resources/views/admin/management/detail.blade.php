@extends('admin.layouts.main')
@section('title','Ngày đi làm ')
@section('content')
<div class="data-table-area mg-b-15">
  <div class="container-fluid">
    @if(Session::has('error'))
    <p class="alert {{ Session::get('alert-class', 'alert-danger') }}">{{ Session::get('error') }}</p>
    @elseif(Session::has('success'))
    <p class="alert {{ Session::get('alert-class', 'alert-success') }}">{{ Session::get('success') }}</p>
    @endif
      <div class="row">
          <div class="col-lg-12">
              <div class="sparkline13-list shadow-reset">
                  <div class="sparkline13-hd">
                      <div class="main-sparkline13-hd">
                          <h1 style="font-weight: bold;">Tổng Ngày Đi Làm <i class="fa big-icon fa-calendar"></i></h1>
                          <div class="sparkline13-outline-icon">
                              <span class="sparkline13-collapse-link"><i class="fa fa-chevron-up"></i></span>
                              <span><i class="fa fa-wrench"></i></span>
                              <span class="sparkline13-collapse-close"><i class="fa fa-times"></i></span>
                          </div>
                      </div>
                  </div>
                  
                  <div class="sparkline13-graph">
                      <div class="datatable-dashv1-list custom-datatable-overright">
                          <div id="toolbar">
                          
                            @if($startDate)
                              {{ Form::open(['route' => 'tinhluong', 'method' => 'post']) }} 
                              <div class="col-lg-12 row">
                              
                                <div class="form-group-inner">
                                    <div class="row">

                                      <div class="col-lg-1">
                                          <label>Start</label>
                                      </div>
                                      <div class="col-lg-4">
                                          <input type="hidden" name="id" value="{{$employees->id}}" id="">
                                        <input class="form-control" type="date" id="from" name="from" value="{{$startDate->date}}">
                                      </div>

                                      <div class="col-lg-1">
                                          <label >End</label>
                                      </div>
                                      <div class="col-lg-4 ">
                                          <input class="form-control" type="date" id="to" name="to"  value="{{$endDate->date}}"> 
                                      </div>
                                      {{form::submit('Tính Lương ',['class'=>'btn btn-success']) }}
                                    </div>
                                  </div>
                              </div>    
                              </div>
                                {{ Form::close()}}
                                @else
                                  <h5>Thông Báo: Nhân Viên Không có ngày Đi Làm trong tháng này!</h5>
                                @endif
                          </div>
                          <table id="table" data-toggle="table" data-pagination="true" data-search="true" data-show-columns="true" data-show-pagination-switch="true" data-show-refresh="true" data-key-events="true" data-show-toggle="true" data-resizable="true" data-cookie="true" data-cookie-id-table="saveId" data-show-export="true" data-click-to-select="true" data-toolbar="#toolbar">
                              <thead>
                                  <tr>
                                      <th>STT</th>
                                      <th>Tên Nhân Viên</th>
                                      <th>ID</th>                                    
                                      <th>Giờ Vào</th>
                                      <th>Ngày đi làm</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  @foreach($dateworks as $key => $datework)
                                    <tr>
                                      <td>{{++$key}}</td>
                                      <td>{{$datework->Employee->name}}</td>
                                      <td>{{$datework->Employee->employee_code}}</td>
                                      <td>{{$datework->intime}}</td>
                                      <td>{{$datework->date}}</td>
                                    </tr>
                                  @endforeach
                                </tbody>
                          </table>
                          
                      </div>
                  </div>
                  
              </div>
          </div>
      </div>
  </div>
</div>

@endsection
@section('script')
@include('admin.shared.script')
@endsection