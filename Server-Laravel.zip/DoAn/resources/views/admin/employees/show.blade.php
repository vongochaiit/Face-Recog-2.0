@extends('admin.layouts.main')
@section('title','Danh sách Employee')
@section('content')
 <div class="container-fluid">
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h3 class="m-0 font-weight-bold text-gray-dark" style="font-weight: bold;">Thông Tin Nhân viên <i class="fa big-icon fa-user"></i></h3>
    </div>
      <div class="card row" >

        <div class="col-md-3">
          <img class="img-thumbnail" style="width: 100%; height: 480px" src="{{asset('/storage/images/'. $employees->avatar)}}" alt="avatar">
        </div>
        <div class="col-md-5" >

            <ul class="list-group list-group-flush">
              <li class="list-group-item"><h5><i class="fa big-icon fa-user"></i> Mã Nhân Viên: {{ $employees->employee_code}}</h5></li>
              <li class="list-group-item"><h5> <i class="fa big-icon fa-user"></i> Tên Nhân Viên: {{ $employees->name}}</h5></li>
              <li class="list-group-item"><h5><i class="fa big-icon fa-venus-mars"></i> Giới tính:
              @if ($employees->gender == 1)
                Nam
                @elseif ($employees->gender == 0) 
                Nữ
              @endif
            </h5></li>
              <li class="list-group-item"><h5><i class="fa big-icon fa-birthday-cake"></i> Ngày Sinh: {{ $employees->birthday}}</h5></li>
              <li class="list-group-item"><h5> <i class="fa big-icon fa-map"></i> Địa Chỉ: {{ $employees->address}}</h5></li>
              <li class="list-group-item"><h5> <i class="fa big-icon fa-phone"></i> Số Điện Thoại: {{ $employees->phone_number}}</h5></li>
              <li class="list-group-item"><h5> <i class="fa big-icon fa-building"></i> Công Ty: {{ $employees->Company->name}}</h5></li>
              <li class="list-group-item"><h5> <i class="fa big-icon fa-bar-chart-o"></i> Chức Vụ: {{ $employees->Position->name}}</h5></li>
            </ul>

            <div class="col-md-12 ">
          @if($startDate)
          <div class="col-md-12">
            <div class="card-header py-3">
              <h4 class="m-0 font-weight-bold text-gray-dark" style="font-weight: bold;">Ngày Đi Làm</h4>
            </div>
            {{ Form::open(['route' => 'tinhluong', 'method' => 'post']) }}           
              <label for="from">From</label>
              <input type="hidden" name="id" value="{{$employees->id}}" id="">
              <input type="date" id="from" name="from" value="{{$startDate->date}}">
              <label for="to">to</label>
              <input type="date" id="to" name="to"  value="{{$endDate->date}}"> 
              {{form::submit('Tính ',['class'=>'btn btn-primary']) }}
              {{ Form::close()}}
          </div>
          @else
            <h5>Thông Báo: Nhân Viên Không có ngày Đi Làm trong tháng này!</h5>
          @endif
        </div>
          </div>

        
      </div>

    </div>
 </div>

 <style type="text/css">
   h5{
    font-weight: bold;
   }
 </style>

@endsection
@section('script')
@include('admin.shared.script')
@endsection