@extends('admin.layouts.main')
@section('title','Danh sách images')
@section('content')
<div class="data-table-area mg-b-15">
  <div class="container-fluid">
    @if(Session::has('error'))
    <p class="alert {{ Session::get('alert-class', 'alert-danger') }}">{{ Session::get('error') }}</p>
    @elseif(Session::has('success'))
    <p class="alert {{ Session::get('alert-class', 'alert-success') }}">{{ Session::get('success') }}</p>
    @endif
      <div class="row">
          <div class="col-lg-12">
              <div class="sparkline13-list shadow-reset">
                  <div class="sparkline13-hd">
                      <div class="main-sparkline13-hd">
                          <h1>Images</h1>
                          <div class="sparkline13-outline-icon">
                              <span class="sparkline13-collapse-link"><i class="fa fa-chevron-up"></i></span>
                              <span><i class="fa fa-wrench"></i></span>
                              <span class="sparkline13-collapse-close"><i class="fa fa-times"></i></span>
                          </div>
                      </div>
                  </div>
                  <form action="{{ url('/imageDeleteAll')}}" method="post">
                            {!! csrf_field() !!}
                  <div class="sparkline13-graph">
                      <div class="datatable-dashv1-list custom-datatable-overright">
                          <div id="toolbar">
                              <a href="{{ route('image-upload.create')}}" class="btn btn-success">Thêm Mới</a>
                              <button type="submit" class="btn btn-danger">Xóa Nhiều Ảnh</button>
                          </div>
                          
                            
                          <table id="table" data-toggle="table" data-pagination="true" data-search="true" data-show-columns="true" data-show-pagination-switch="true" data-show-refresh="true" data-key-events="true" data-show-toggle="true" data-resizable="true" data-cookie="true" data-cookie-id-table="saveId" data-show-export="true" data-click-to-select="true" data-toolbar="#toolbar">
                              <thead>
                                  <tr>
                                      <th>#</th>
                                      <th>STT</th>
                                      <th>Ảnh</th>
                                      <th>Nhân Viên</th>
                                      <th>Action</th>
                                  </tr>
                                </thead>
                                <tbody>
                                   @foreach($images as $key => $image)
                                    <tr id="tr_{{$image->id}}">
                                        <td><input type="checkbox" name="ids[]" value="{{$image->id}}"></td>
                                        <td> {{++$key}} </td>
                                        <td><img style="width:120px; height:120px" 
                                        src="{{asset('images/')}}/{{$image->name}}"></td>
                                        <td>{{$image->Employee->name }}</td>
                                        <td>
                                          <div class="row" style="text-align: center;">
                                            <a class="btn-link btn" 
                                               href="{{ route('image-upload.edit',$image->id) }}">
                                               <i style="color: #fcba03" class="fa big-icon fa-edit"></i>
                                            </a>
                                            <a class="btn-link btn">
                                            {{ Form::open(['route' => ['image-upload.destroy',$image->id], 'method'=> 'DELETE'])}}
                                            {{ Form::button('<i style="color: red" class="fa big-icon fa-trash"></i>',
                                            ['type'=> 'submit','class' =>'btn-link btn'])}}
                                            {{ Form::close() }}
                                            </a>
                                          </div>
                                        </td>
                                    </tr>
                                    @endforeach
                                  </tbody>
                          </table>
                          
                      </div>
                  </div>
                  </form>
              </div>
          </div>
      </div>
  </div>
</div>

@endsection
@section('script')
@include('admin.shared.script')
@endsection