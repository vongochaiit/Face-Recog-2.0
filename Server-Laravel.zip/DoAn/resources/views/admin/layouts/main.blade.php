<!DOCTYPE html>
<html lang="en">
<head>
  @include('admin.shared.links')
</head>

<body class="materialdesign">

  <div id="wrapper-pro">
    @include('admin.layouts.menuleft')

    <div id="content-wrapper" class="d-flex flex-column">
      <div id="content">
        @include('admin.layouts.header')

        @yield('content')
      
      </div>
      @include('admin.layouts.footer')
    </div>
  </div>
  @yield('script')

</body>
</html>
