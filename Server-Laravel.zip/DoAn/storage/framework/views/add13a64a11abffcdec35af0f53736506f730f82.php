
<?php $__env->startSection('title','Danh sách salary'); ?>
<?php $__env->startSection('content'); ?>
 <div class="container-fluid">
 	<div class="card shadow mb-4">
        <?php if(Session::has('error')): ?>
        <p class="alert <?php echo e(Session::get('alert-class', 'alert-danger')); ?>"><?php echo e(Session::get('error')); ?></p>
        <?php elseif(Session::has('success')): ?>
        <p class="alert <?php echo e(Session::get('alert-class', 'alert-success')); ?>"><?php echo e(Session::get('success')); ?></p>
        <?php endif; ?>
        <div class="card-header py-3">
          <h3 class="m-0 font-weight-bold text-gray-dark">Salary</h3>
        </div>
        <div class="card-body">
          <div class="table-responsive">
			     <a href="<?php echo e(route('salaries.create')); ?>" class="btn btn-success">Add New</a>
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            	<thead>
                    <tr>
                      <th>STT</th>
                      <th>Lương Cơ Bản</th>
                      <th>Hệ Số Lương</th>
                      <th>Lương Được Nhận</th>
                      <th colspan="3">Action</th>
                    </tr>
                </thead>
                <tbody>
                	<?php $__currentLoopData = $salaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                	<tr>
                      <td > <?php echo e(++$key); ?> </td>
                      <td><?php echo e(number_format($salary->luong_cb)); ?>.vnđ</td>
                      <td><?php echo e($salary->hs_luong); ?></td>
                      <td><?php echo e(number_format($salary->luong_nhan)); ?>.vnđ</td>
                      <td>
                      	<div class="row">
                      		<a class="p-0 ml-2 btn-link btn " 
                      		   href="<?php echo e(route('salaries.show',$salary->id)); ?>">
                      		   <i class="far fa-eye text-success"></i>
                      		</a>
                      		<a class="p-0 ml-2 btn-link btn" 
                      			href="<?php echo e(route('salaries.edit',$salary->id)); ?>">
								<i class="fas fa-edit text-warning"></i>
							</a>
							<?php echo e(Form::open(['route' => ['salaries.destroy',$salary->id], 'method'=> 'DELETE'])); ?>


							<?php echo e(Form::button('<i class="fas fa-trash-alt text-danger"></i>',
							['type'=> 'submit','class' =>'p-0 ml-2 btn-link btn'])); ?>

							<?php echo e(Form::close()); ?>

                      	</div>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>  
            </table>
          </div>
        </div>
    </div>
 </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php echo $__env->make('admin.shared.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DoAn\resources\views/admin/salaries/index.blade.php ENDPATH**/ ?>