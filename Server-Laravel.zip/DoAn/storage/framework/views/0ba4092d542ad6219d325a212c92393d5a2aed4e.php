
<?php $__env->startSection('title','Danh sách Position'); ?>
<?php $__env->startSection('content'); ?>
<div class="data-table-area mg-b-15">
  <div class="container-fluid">
    <?php if(Session::has('error')): ?>
    <p class="alert <?php echo e(Session::get('alert-class', 'alert-danger')); ?>"><?php echo e(Session::get('error')); ?></p>
    <?php elseif(Session::has('success')): ?>
    <p class="alert <?php echo e(Session::get('alert-class', 'alert-success')); ?>"><?php echo e(Session::get('success')); ?></p>
    <?php endif; ?>
      <div class="row">
          <div class="col-lg-12">
              <div class="sparkline13-list shadow-reset">
                  <div class="sparkline13-hd">
                      <div class="main-sparkline13-hd">
                          <h1 style="font-weight: bold;">Chức Vụ <i class="fa big-icon fa-bar-chart-o"></i></h1>
                          <div class="sparkline13-outline-icon">
                              <span class="sparkline13-collapse-link"><i class="fa fa-chevron-up"></i></span>
                              <span><i class="fa fa-wrench"></i></span>
                              <span class="sparkline13-collapse-close"><i class="fa fa-times"></i></span>
                          </div>
                      </div>
                  </div>
                  <div class="sparkline13-graph">
                      <div class="datatable-dashv1-list custom-datatable-overright">
                          <div id="toolbar">
                              <a href="<?php echo e(route('positions.create')); ?>" class="btn btn-success">Thêm Mới</a>
                          </div>
                          <table id="table" data-toggle="table" data-pagination="true" data-search="true" data-show-columns="true" data-show-pagination-switch="true" data-show-refresh="true" data-key-events="true" data-show-toggle="true" data-resizable="true" data-cookie="true" data-cookie-id-table="saveId" data-show-export="true" data-click-to-select="true" data-toolbar="#toolbar">
                              <thead>
                                  <tr>
                                      
                                      <th>STT</th>
                                      <th>Mã Chức Vụ</th>
                                      <th>Chức Vụ</th>
                                      <th>Hệ Số Lương</th>
                                      <th>Lương Nhận</th>
                                      <th>Action</th>
                                  </tr>
                                </thead>
                                <tbody>
                                   <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                       
                                        <td > <?php echo e(++$key); ?> </td>
                                        <td><?php echo e($position->position_code); ?></td>
                                        <td><?php echo e($position->name); ?></td>
                                        <td><?php echo e($position->salary->hesoluong); ?></td>
                                        <td><?php echo e(number_format($position->salary->luongnhan)); ?>.vnđ</td>
                                        <td>
                                          <div class="row" style="text-align: center;">
                                            <a class="btn-link btn" 
                                               href="<?php echo e(route('positions.edit',$position->id)); ?>">
                                               <i style="color: #fcba03" class="fa big-icon fa-edit"></i>
                                            </a>
                                            <a class="btn-link btn">
                                            <?php echo e(Form::open(['route' => ['positions.destroy',$position->id], 'method'=> 'DELETE'])); ?>

                                            <?php echo e(Form::button('<i style="color: red" class="fa big-icon fa-trash"></i>',
                                            ['type'=> 'submit','class' =>'btn-link btn'])); ?>

                                            <?php echo e(Form::close()); ?>

                                            </a>
                                          </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </tbody>
                          </table>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php echo $__env->make('admin.shared.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DoAn\resources\views/admin/positions/index.blade.php ENDPATH**/ ?>