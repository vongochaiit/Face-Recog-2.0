<!DOCTYPE html>
<html lang="en">
<head>
  <?php echo $__env->make('admin.shared.links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="materialdesign">

  <div id="wrapper-pro">
    <?php echo $__env->make('admin.layouts.menuleft', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div id="content-wrapper" class="d-flex flex-column">
      <div id="content">
        <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('content'); ?>
      
      </div>
      <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </div>
  <?php echo $__env->yieldContent('script'); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\DoAn\resources\views/admin/layouts/main.blade.php ENDPATH**/ ?>