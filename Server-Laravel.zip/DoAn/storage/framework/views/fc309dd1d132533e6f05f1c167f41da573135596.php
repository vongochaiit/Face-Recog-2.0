
<?php $__env->startSection('title','Edit company'); ?>
<?php $__env->startSection('content'); ?>
 <div class="row">
    <div class="col-lg-12">
        <div class="sparkline12-list shadow-reset mg-t-30">
            <div class="sparkline12-hd">
                <div class="main-sparkline12-hd">
                    <h1>Sửa Công Ty</h1>
                    <div class="sparkline12-outline-icon">
                        <span class="sparkline12-collapse-link"><i class="fa fa-chevron-up"></i></span>
                        <span><i class="fa fa-wrench"></i></span>
                        <span class="sparkline12-collapse-close"><i class="fa fa-times"></i></span>
                    </div>
                </div>
            </div>
            <div class="sparkline12-graph">
              <div class="basic-login-form-ad">
                  <div class="row">
                      <div class="col-lg-12">
                          <div class="all-form-element-inner">
                              <?php echo e(Form::model($company,['route'=>['companies.update',$company->id],'method'=>'put'])); ?>

                                <div class=" col-lg-12 row">
                                <div class="col-lg-6">
                                  <div class="form-group-inner">
                                    <div class="row">
                                      <div class="col-lg-3">
                                          <label class="login2 pull-right pull-right-pro">ID</label>
                                      </div>
                                      <div class="col-lg-8">
                                        <?php echo e(Form::text('companies_code',$company->companies_code,['class'=>'form-control '])); ?>

                                        <span class="text-danger"><?php echo e($errors->first('companies_code')); ?></span>
                                      </div>
                                    </div>
                                  </div>

                                <div class="form-group-inner">
                                  <div class="row">
                                    <div class="col-lg-3">
                                        <label class="login2 pull-right pull-right-pro">Tên Công Ty</label>
                                    </div>
                                    <div class="col-lg-8">
                                        <?php echo e(Form::text('name',$company->name,['class'=>'form-control '])); ?>

                                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                    </div>
                                  </div> 
                                </div>

                                <div class="form-group-inner">
                                  <div class="row">
                                      <div class="col-lg-3 ">
                                          <label class="login2 pull-right pull-right-pro">Địa Chỉ</label>
                                      </div>
                                      <div class="col-lg-8 ">
                                          <?php echo e(Form::text('address',$company->address,['class'=>'form-control '])); ?>

                                          <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                                      </div>
                                  </div>
                                </div>

                                <div class="form-group-inner">
                                    <div class="row">
                                      <div class="col-lg-3">
                                          <label class="login2 pull-right pull-right-pro">Ngày Sinh</label>
                                      </div>
                                      <div class="col-lg-8">
                                        <?php echo e(Form::text('email',$company->email,['class'=>'form-control '])); ?>

                                        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                      </div>
                                    </div>
                                  </div>
                              </div>

                            </div>
                          </div>

                          <div class="form-group-inner">
                            <div class="login-btn-inner">
                              <div class="row">
                                <div class="col-lg-3"></div>
                                <div class="col-lg-9">
                                    <div class="login-horizental cancel-wp pull-left">
                                      <a href="<?php echo e(route('companies.index')); ?>" class="btn btn-default">Cancel</a>
                                      <?php echo e(Form::submit('Save Change',["class"=> "btn btn-sm btn-primary login-submit-cs"])); ?>

                                    </div>
                                </div>
                              </div>                    
                            </div>
                          </div>
                        <?php echo e(Form::close()); ?>


                          </div>
                      </div>
                  </div>
              </div>
          </div>
        </div>
    </div>
 </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php echo $__env->make('admin.shared.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DoAn\resources\views/admin/companies/edit.blade.php ENDPATH**/ ?>