
<?php $__env->startSection('title','Danh sách Chức Vụ'); ?>
<?php $__env->startSection('content'); ?>
 <div class="row">
    <div class="col-lg-12">
      <?php if(Session::has('error')): ?>
        <p class="alert <?php echo e(Session::get('alert-class', 'alert-danger')); ?>"><?php echo e(Session::get('error')); ?></p>
        <?php elseif(Session::has('success')): ?>
        <p class="alert <?php echo e(Session::get('alert-class', 'alert-success')); ?>"><?php echo e(Session::get('success')); ?></p>
      <?php endif; ?>
        <div class="sparkline12-list shadow-reset mg-t-30">
            <div class="sparkline12-hd">
                <div class="main-sparkline12-hd">
                    <h1 style="font-weight: bold;"> Tạo Chức Vụ <i class="fa big-icon fa-bar-chart-o"></i></h1>
                    <div class="sparkline12-outline-icon">
                        <span class="sparkline12-collapse-link"><i class="fa fa-chevron-up"></i></span>
                        <span><i class="fa fa-wrench"></i></span>
                        <span class="sparkline12-collapse-close"><i class="fa fa-times"></i></span>
                    </div>
                </div>
            </div>
            <div class="sparkline12-graph">
              <div class="basic-login-form-ad">
                  <div class="row">
                      <div class="col-lg-12">
                          <div class="all-form-element-inner">
                              <?php echo e(Form::open([ 'url'=>'positions','method'=>'post' ])); ?>

                                <div class=" col-lg-12 row">
                                <div class="col-lg-6">
                                  <div class="form-group-inner">
                                    <div class="row">
                                      <div class="col-lg-3">
                                          <label class="login2 pull-right pull-right-pro">ID</label>
                                      </div>
                                      <div class="col-lg-8">
                                        <?php echo e(Form::text('position_code','',['class'=>'form-control '])); ?>

                                        <span class="text-danger"><?php echo e($errors->first('position_code')); ?></span>
                                      </div>
                                    </div>
                                  </div>

                                <div class="form-group-inner">
                                  <div class="row">
                                    <div class="col-lg-3">
                                        <label class="login2 pull-right pull-right-pro">Chức Vụ</label>
                                    </div>
                                    <div class="col-lg-8">
                                        <?php echo e(Form::text('name','',['class'=>'form-control '])); ?>

                                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                    </div>
                                  </div> 
                                </div>

                                <div class="form-group-inner">
                                  <div class="row">
                                      <div class="col-lg-3 ">
                                          <label class="login2 pull-right pull-right-pro">Lương Cơ Bản</label>
                                      </div>
                                      <div class="col-lg-8 ">
                                          <?php echo e(Form::text('luongcoban','',['class'=>'form-control','id'=>'qty'])); ?>

                                          <span class="text-danger"><?php echo e($errors->first('luongcoban')); ?></span>
                                      </div>
                                  </div>
                                </div>

                                <div class="form-group-inner">
                                    <div class="row">
                                      <div class="col-lg-3">
                                          <label class="login2 pull-right pull-right-pro">Hệ Số Lương</label>
                                      </div>
                                      <div class="col-lg-8">
                                          <?php echo e(Form::text('hesoluong','',['class'=>'form-control','id'=>'price'])); ?>

                                          <span class="text-danger"><?php echo e($errors->first('hesoluong')); ?></span>
                                      </div>
                                    </div>
                                  </div>

                                  <div class="form-group-inner">
                                    <div class="row">
                                      <div class="col-lg-3">
                                          <label class="login2 pull-right pull-right-pro">Lương</label>
                                      </div>
                                      <div class="col-lg-8">
                                          <?php echo e(Form::text('luongnhan','',['class'=>'form-control','id'=>'total'])); ?>

                                          <span class="text-danger"><?php echo e($errors->first('luongnhan')); ?></span>
                                      </div>
                                    </div>
                                  </div>
                              </div>

                            </div>
                          </div>

                          <div class="form-group-inner">
                            <div class="login-btn-inner">
                              <div class="row">
                                <div class="col-lg-3"></div>
                                <div class="col-lg-9">
                                    <div class="login-horizental cancel-wp pull-left">
                                      <a href="<?php echo e(route('positions.index')); ?>" class="btn btn-default">Trở lại</a>
                                      <?php echo e(Form::submit('Lưu',["class"=> "btn btn-sm btn-primary login-submit-cs"])); ?>

                                    </div>
                                </div>
                              </div>                    
                            </div>
                          </div>
                        <?php echo e(Form::close()); ?>


                          </div>
                      </div>
                  </div>
              </div>
          </div>
        </div>
    </div>
 </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php echo $__env->make('admin.shared.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DoAn\resources\views/admin/positions/create.blade.php ENDPATH**/ ?>