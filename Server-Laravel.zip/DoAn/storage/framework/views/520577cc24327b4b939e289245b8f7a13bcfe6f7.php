<!-- jquery
    ============================================ -->
    <script src="<?php echo e(asset('admin/js/vendor/jquery-1.11.3.min.js')); ?>"></script>
    <!-- bootstrap JS
    ============================================ -->
    <script src="<?php echo e(asset('admin/js/bootstrap.min.js')); ?>"></script>
    <!-- meanmenu JS
    ============================================ -->
    <script src="<?php echo e(asset('admin/js/jquery.meanmenu.js')); ?>"></script>
    <!-- mCustomScrollbar JS
    ============================================ -->
    <script src="<?php echo e(asset('admin/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
    <!-- sticky JS
    ============================================ -->
    <script src="<?php echo e(asset('admin/js/jquery.sticky.js')); ?>"></script>
    <!-- scrollUp JS
    ============================================ -->
    <script src="<?php echo e(asset('admin/js/jquery.scrollUp.min.js')); ?>"></script>
    <!-- scrollUp JS
    ============================================ -->
    <script src="<?php echo e(asset('admin/js/wow/wow.min.js')); ?>"></script>
    <!-- counterup JS
    ============================================ -->
    <script src="<?php echo e(asset('admin/js/counterup/jquery.counterup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/counterup/waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/counterup/counterup-active.js')); ?>"></script>
    
    <!-- peity JS
    ============================================ -->
    <script src="<?php echo e(asset('admin/js/peity/jquery.peity.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/peity/peity-active.js')); ?>"></script>
    <!-- sparkline JS
    ============================================ -->
    <script src="<?php echo e(asset('admin/js/sparkline/jquery.sparkline.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/sparkline/sparkline-active.js')); ?>"></script>
    <!-- flot JS
    ============================================ -->
    
    <!-- data table JS
    ============================================ -->
    <script src="<?php echo e(asset('admin/js/data-table/bootstrap-table.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/data-table/tableExport.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/data-table/data-table-active.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/data-table/bootstrap-table-editable.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/data-table/bootstrap-editable.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/data-table/bootstrap-table-resizable.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/data-table/colResizable-1.5.source.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/data-table/bootstrap-table-export.js')); ?>"></script>
    <!-- main JS
    ============================================ -->
    <script src="<?php echo e(asset('admin/js/main.js')); ?>"></script>

<!-- add product -->

<script >
	$('#qty, #price').on('input', function() {
  	var qty = parseInt($('#qty').val());
  	var price = parseFloat($('#price').val());
  	$('#total').val((qty * price/26 ? qty * price/26 : 0).toFixed(0));
});
</script>  
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>

<!-- upload -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script >
    $(document).ready(function() {
      if (window.File && window.FileList && window.FileReader) {
        $("#images").on("change", function(e) {
          var files = e.target.files,
            filesLength = files.length;
          for (var i = 0; i < filesLength; i++) {
            var f = files[i]
            var fileReader = new FileReader();
            fileReader.onload = (function(e) {
              var file = e.target;
              $("<span class=\"pip\">" +
                "<img class=\"imageThumb\" src=\"" + e.target.result + "\" title=\"" + file.name + "\"/>" +
                "<br/><span class=\"remove\">Delete</span>" +
                "</span>").insertAfter("#images");
              $(".remove").click(function(){
                $(this).parent(".pip").remove();
              });
            });
                fileReader.readAsDataURL(f);
            }
        });
      }else {
            alert("Your browser doesn't support to File API")
        }
    });
</script>

<!-- API -->
<!--Serve:  http://laravelapi.ddns.net/api/showEmployee -->
<!-- Local: http://127.0.0.1:8000/api/showEmployee -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
$(document).ready(function(){

    setInterval(function(){
        $.ajax({

            url: 'http://127.0.0.1:8000/api/showEmployee',
            type: 'GET',
             
        success: function(data) {
            console.log('data',data);
        var html ="";
        $.each(data, function (key, item) {
        html += '<div class= "col-md-2 ">';
        html += '<img class="img-thumbnail" src="http://laravelapi.ddns.net/storage/images/' + item.avatar + '" />';
        html += '<h5>'+item.name+'</h5>';
        html += '<p class="card-text">ID : '+item.employee_code+' </p>';
        html += '<p style="background: #6ce856" class="card-text">Intime : '+item.managements[0].intime+'</p>';
        html += '</div>';
    });
   
        $(".container").html(html);

                }
            });
        },3000);
});
</script><?php /**PATH C:\xampp\htdocs\DoAn\resources\views/admin/shared/script.blade.php ENDPATH**/ ?>