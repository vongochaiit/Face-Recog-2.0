
<?php $__env->startSection('title','Danh sách Position'); ?>
<?php $__env->startSection('content'); ?>
 <div class="container-fluid">
 	<div class="card shadow mb-4">
        <div class="card-header py-3">
          <h3 class="m-0 font-weight-bold text-gray-dark">Position Detail</h3>
        </div>
        <div class="card-body">

          <div class="table-responsive">
			       <br>
                <div class="col-3">
                  <p>Mã Chức Vụ: <?php echo e($position->position_code); ?></p>
                </div>

                <div class="col-3">
                  <p>Chức Vụ: <?php echo e($position->name); ?></p>
                </div>

                
                <a style="margin-left: 15px" href="<?php echo e(route('positions.index')); ?>" class="btn btn-primary">Back</a>
            
          </div>
        </div>
    </div>
 </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php echo $__env->make('admin.shared.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DoAn\resources\views/admin/positions/show.blade.php ENDPATH**/ ?>