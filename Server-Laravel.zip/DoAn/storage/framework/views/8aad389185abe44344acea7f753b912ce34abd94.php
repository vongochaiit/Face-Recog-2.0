
<?php $__env->startSection('title','Danh sách images'); ?>
<?php $__env->startSection('content'); ?>

<div class="data-table-area mg-b-15">
  <div class="container-fluid">
    <?php if(Session::has('error')): ?>
    <p class="alert <?php echo e(Session::get('alert-class', 'alert-danger')); ?>"><?php echo e(Session::get('error')); ?></p>
    <?php elseif(Session::has('success')): ?>
    <p class="alert <?php echo e(Session::get('alert-class', 'alert-success')); ?>"><?php echo e(Session::get('success')); ?></p>
    <?php endif; ?>
      <div class="row">
          <div class="col-lg-12">
              <div class="sparkline13-list shadow-reset">
                  <div class="sparkline13-hd">
                      <div class="main-sparkline13-hd">
                          <h1 style="font-weight: bold;">Điểm Danh</h1>
                          <div class="sparkline13-outline-icon">
                            <form action="<?php echo e(route('search')); ?>" method="get">
                              <div class="form-group-inner">
                                  <div class="row">
                                    <div class="col-lg-8" >
                                        <select style="background: #6ce856; margin-left: 15px;" class="form-control" name="date" >

                                            <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option  value="<?php echo e($day); ?>" 
                                              <?php if($date == $day): ?>
                                              selected
                                              <?php endif; ?>><?php echo e($day); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </select>
                                    </div>
                                    <div class="col-lg-2" >
                                        <button class="btn btn-info" type="submit" id="search">Search</button>
                                    </div>
                                  </div> 
                                </div>
                            </form>
                          </div>
                      </div>
                  </div>
                  <div class="container">
                  <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class= "col-md-2 ">
                    <img class="img-thumbnail" src="http://laravelapi.ddns.net/storage/images/<?php echo e($item->avatar); ?>" />
                    <h5><?php echo e($item->name); ?></h5>
                    <p class="card-text">ID : <?php echo e($item->employee_code); ?> </p>
                    <p style="background: #6ce856">Intime: <?php echo e($item->managements[0]->intime); ?></p>

                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                  
              </div>
          </div>
      </div>
  </div>
</div>



<style>
    .container{
      width: 100%;
    }
    .img-thumbnail{
        width:180px;
        height:180px;
    }
    .col-md-2{
      padding-top: 30px;
      text-align: center;


    }
    h5{
      margin-top: 15px;
      font-weight: bold;

    }
</style>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DoAn\resources\views/admin/management/list_by_date.blade.php ENDPATH**/ ?>