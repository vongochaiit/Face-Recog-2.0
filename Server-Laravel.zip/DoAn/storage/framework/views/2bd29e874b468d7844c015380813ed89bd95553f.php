
<?php $__env->startSection('title','Danh sách Salary'); ?>
<?php $__env->startSection('content'); ?>
 <div class="container-fluid">
  <div class="card shadow mb-4">
        <div class="card-header py-3">
          <h3 class="m-0 font-weight-bold text-gray-dark">Create Salary</h3>
        </div>
        <div class="card-body">
          <?php echo e(Form::open([ 'url'=>'salaries','method'=>'post' ])); ?>

          <div class="col-6">
            <div class="form-group ">
              <?php echo e(Form::label('Lương Cơ Bản')); ?>

              <?php echo e(Form::text('luong_cb','',['class'=>'form-control','id'=>'qty'])); ?>

              <span class="text-danger"><?php echo e($errors->first('luong_cb')); ?></span>
            </div>
            <div class="form-group ">
              <?php echo e(Form::label('Hệ Số Lương')); ?>

              <?php echo e(Form::text('hs_luong','',['class'=>'form-control','id'=>'price'])); ?>

              <span class="text-danger"><?php echo e($errors->first('hs_luong')); ?></span>
            </div>
            <div class="form-group ">
              <?php echo e(Form::label('Lương Được Nhận')); ?>

              <?php echo e(Form::text('luong_nhan','',['class'=>'form-control','id'=>'total'])); ?>

              <span class="text-danger"><?php echo e($errors->first('luong_nhan')); ?></span>
            </div>

            <?php echo e(Form::submit('Gửi',["class"=> "btn btn-success"])); ?>

            <a href="<?php echo e(route('salaries.index')); ?>" class="btn btn-primary">Back</a>
          <?php echo e(Form::close()); ?>

              </div>
        </div>
 </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php echo $__env->make('admin.shared.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DoAn\resources\views/admin/salaries/create.blade.php ENDPATH**/ ?>