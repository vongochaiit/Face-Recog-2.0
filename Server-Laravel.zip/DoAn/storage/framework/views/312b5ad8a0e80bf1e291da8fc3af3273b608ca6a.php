
<?php $__env->startSection('title','Danh sách Employee'); ?>
<?php $__env->startSection('content'); ?>
 <div class="row">
    <div class="col-lg-12">
        <div class="sparkline12-list shadow-reset mg-t-30">
            <div class="sparkline12-hd">
                <div class="main-sparkline12-hd">
                    <h1>Sửa Nhân Viên</h1>
                    <div class="sparkline12-outline-icon">
                        <span class="sparkline12-collapse-link"><i class="fa fa-chevron-up"></i></span>
                        <span><i class="fa fa-wrench"></i></span>
                        <span class="sparkline12-collapse-close"><i class="fa fa-times"></i></span>
                    </div>
                </div>
            </div>
            <div class="sparkline12-graph">
              <div class="basic-login-form-ad">
                  <div class="row">
                      <div class="col-lg-12">
                          <div class="all-form-element-inner">
                            <?php echo e(Form::model($employee,['route'=>['employees.update',$employee->id],'method'=>'put', 'enctype'=>"multipart/form-data"])); ?>

                              <?php echo csrf_field(); ?>
                                <div class=" col-lg-12 row">
                                <div class="col-lg-6">

                                  <div class="form-group-inner">
                                    <div class="row">
                                      <div class="col-lg-3">
                                          <label class="login2 pull-right pull-right-pro">ID</label>
                                      </div>
                                      <div class="col-lg-8">
                                          <?php echo e(Form::text('employee_code',$employee->employee_code,['class'=>'form-control '])); ?>

                                          <span class="text-danger"><?php echo e($errors->first('employee_code')); ?></span>
                                      </div>
                                    </div>
                                  </div>

                                <div class="form-group-inner">
                                  <div class="row">
                                    <div class="col-lg-3">
                                        <label class="login2 pull-right pull-right-pro">Họ Và Tên</label>
                                    </div>
                                    <div class="col-lg-8">
                                        <?php echo e(Form::text('name',$employee->name,['class'=>'form-control '])); ?>

                                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                    </div>
                                  </div> 
                                </div>

                                <div class="form-group-inner">
                                  <div class="row">
                                      <div class="col-lg-3 col-md-9 col-sm-9 col-xs-9">
                                          <label class="login2 pull-right pull-right-pro">giới Tính</label>
                                      </div>
                                      <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">
                                          <?php echo e(Form::label('Nam')); ?>

                                          <?php echo e(Form::radio('gender',1,true)); ?>

                                          <?php echo e(Form::label('Nữ')); ?>

                                          <?php echo e(Form::radio('gender',0)); ?>

                                          <span class="text-danger"><?php echo e($errors->first('gender')); ?></span>
                                      </div>
                                  </div>
                                </div>

                                <div class="form-group-inner">
                                    <div class="row">
                                      <div class="col-lg-3">
                                          <label class="login2 pull-right pull-right-pro">Ngày Sinh</label>
                                      </div>
                                      <div class="col-lg-8">
                                          <?php echo e(Form::date('birthday',$employee->birthday,['class'=>'form-control '])); ?>

                                          <span class="text-danger"><?php echo e($errors->first('birthday')); ?></span>
                                      </div>
                                    </div>
                                  </div>

                                  <div class="form-group-inner">
                                  <div class="row">
                                    <div class="col-lg-3">
                                        <label class="login2 pull-right pull-right-pro" for="images">Chọn Ảnh</label>
                                    </div>
                                    <div class="col-lg-8">

                                      <input type="file" name="image" class="custom-file-input" id="images" >

                                      <span class="pip">
                                      <img class="imageThumb" src="<?php echo e(asset('/storage/images/')); ?>/<?php echo e($employee->avatar); ?>" >
                                      <br>
                                      <span class="remove" style="background: red" >Delete</span>
                                    </span>
                                    </div>
                                  </div>
                                </div>
                                  
                              </div>
                              <div class="col-lg-6">
                                <div class="form-group-inner">
                                  <div class="row">
                                    <div class="col-lg-3">
                                        <label class="login2 pull-right pull-right-pro">Địa Chỉ</label>
                                    </div>
                                    <div class="col-lg-8">
                                        <?php echo e(Form::text('address',$employee->address,['class'=>'form-control '])); ?>

                                        <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                                    </div>
                                  </div>
                                </div>

                                <div class="form-group-inner">
                                  <div class="row">
                                    <div class="col-lg-3">
                                        <label class="login2 pull-right pull-right-pro">Số Điện Thoại</label>
                                    </div>
                                    <div class="col-lg-8">
                                        <?php echo e(Form::text('phone_number',$employee->phone_number,['class'=>'form-control '])); ?>

                                        <span class="text-danger"><?php echo e($errors->first('phone_number')); ?></span>
                                    </div>
                                  </div>
                                </div>
                                  
                                <div class="form-group-inner">
                                  <div class="row">
                                    <div class="col-lg-3">
                                        <label class="login2 pull-right pull-right-pro">Công Ty</label>
                                    </div>
                                    <div class="col-lg-8">
                                        <?php echo e(Form::select('company_id',$companies,null,['class'=>'form-control ','id'=>'companies','placeholder'=>'Chọn Công ty'])); ?>

                                        <span class="text-danger"><?php echo e($errors->first('company_id')); ?></span>
                                    </div>
                                  </div>
                                </div>

                                <div class="form-group-inner">
                                  <div class="row">
                                    <div class="col-lg-3">
                                        <label class="login2 pull-right pull-right-pro">Chức Vụ</label>
                                    </div>
                                    <div class="col-lg-8">
                                        <?php echo e(Form::select('position_id',$positions,null,['class'=>'form-control ','id'=>'positions','placeholder'=>'Chọn Chức vụ'])); ?>

                                        <span class="text-danger"><?php echo e($errors->first('position_id')); ?></span>
                                    </div>
                                  </div>
                                </div>
                              </div>

                            </div>
                          </div>

                          <div class="form-group-inner">
                            <div class="login-btn-inner">
                              <div class="row">
                                <div class="col-lg-9"></div>
                                <div class="col-lg-3">
                                    <div class="login-horizental cancel-wp pull-left">
                                      <a href="<?php echo e(route('employees.index')); ?>" class="btn btn-default">Cancel</a>
                                      <?php echo e(Form::submit('Save Change',["class"=> "btn btn-sm btn-primary login-submit-cs"])); ?>

                                    </div>
                                </div>
                              </div>                    
                            </div>
                          </div>
                        <?php echo e(Form::close()); ?>


                          </div>
                      </div>
                  </div>
              </div>
          </div>
        </div>
    </div>
 </div>
 <style>
    input[type="file"] {
      display: block;
    }
    .imageThumb {
      max-height: 75px;
      border: 2px solid;
      padding: 1px;
      cursor: pointer;
    }
    .pip {
      display: inline-block;
      margin: 10px 10px 0 0;
    }
    .remove {
      display: block;
      background: #444;
      border: 1px solid black;
      color: white;
      text-align: center;
      cursor: pointer;
    }
    .remove:hover {
      background: white;
      color: black;
}
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php echo $__env->make('admin.shared.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DoAn\resources\views/admin/employees/edit.blade.php ENDPATH**/ ?>