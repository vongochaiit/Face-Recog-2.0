
<?php $__env->startSection('title','Danh sách companys'); ?>
<?php $__env->startSection('content'); ?>
<div class="data-table-area mg-b-15">
  <div class="container-fluid">
      <?php if(Session::has('error')): ?>
        <p class="alert <?php echo e(Session::get('alert-class', 'alert-danger')); ?>"><?php echo e(Session::get('error')); ?></p>
        <?php elseif(Session::has('success')): ?>
        <p class="alert <?php echo e(Session::get('alert-class', 'alert-success')); ?>"><?php echo e(Session::get('success')); ?></p>
      <?php endif; ?>
      <div class="row">
          <div class="col-lg-12">
              <div class="sparkline13-list shadow-reset">
                  <div class="sparkline13-hd">
                      <div class="main-sparkline13-hd">
                          <h1 style="font-weight: bold;">Công Ty <i class="fa big-icon fa-building"></i></h1>
                          <div class="sparkline13-outline-icon">
                            
                              <span class="sparkline13-collapse-link"><i class="fa fa-chevron-up"></i></span>
                              <span><i class="fa fa-wrench"></i></span>
                              <span class="sparkline13-collapse-close"><i class="fa fa-times"></i></span>
                          </div>
                      </div>
                  </div>
                  <div class="sparkline13-graph">
                      <div class="datatable-dashv1-list custom-datatable-overright">
                          <div id="toolbar">
                              <a href="<?php echo e(route('companies.create')); ?>" class="btn btn-success">Thêm Mới</a>
                          </div>
                          <table id="table" data-toggle="table" data-pagination="true" data-search="true" data-show-columns="true" data-show-pagination-switch="true" data-show-refresh="true" data-key-events="true" data-show-toggle="true" data-resizable="true" data-cookie="true" data-cookie-id-table="saveId" data-show-export="true" data-click-to-select="true" data-toolbar="#toolbar">
                              <thead>
                                  <tr>
                                      
                                      <th>STT</th>
                                      <th>Mã Công Ty</th>
                                      <th>Tên Công Ty</th>
                                      <th>Địa Chỉ</th>
                                      <th>Email</th>
                                      <th>Action</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <td > <?php echo e(++$key); ?> </td>
                                        <td><?php echo e($company->companies_code); ?></td>
                                        <td><?php echo e($company->name); ?></td>
                                        <td><?php echo e($company->address); ?></td>
                                        <td><?php echo e($company->email); ?></td>
                                        <td>
                                          <div class="row" style="text-align: center;">
                                            <a class="btn-link btn" 
                                               href="<?php echo e(route('companies.edit',$company->id)); ?>">
                                               <i style="color: #fcba03" class="fa big-icon fa-edit"></i>
                                            </a>
                                            <a class="btn-link btn" 
                                            <?php echo e(Form::open(['route' => ['companies.destroy',$company->id], 'method'=> 'DELETE'])); ?>

                                            <?php echo e(Form::button('<i style="color: red" class="fa big-icon fa-trash"></i>',
                                            ['type'=> 'submit','class' =>'btn-link btn'])); ?>

                                            <?php echo e(Form::close()); ?>

                                            </a>
                                          </div>
                                  </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </tbody>
                          </table>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php echo $__env->make('admin.shared.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DoAn\resources\views/admin/companies/index.blade.php ENDPATH**/ ?>