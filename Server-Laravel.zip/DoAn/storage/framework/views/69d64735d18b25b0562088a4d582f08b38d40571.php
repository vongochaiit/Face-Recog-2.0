

<?php $__env->startSection('title','Danh sách Employees'); ?>
<?php $__env->startSection('content'); ?>
<div class="data-table-area mg-b-15">
  <div class="container-fluid">
      <?php if(Session::has('error')): ?>
        <p class="alert <?php echo e(Session::get('alert-class', 'alert-danger')); ?>"><?php echo e(Session::get('error')); ?></p>
        <?php elseif(Session::has('success')): ?>
        <p class="alert <?php echo e(Session::get('alert-class', 'alert-success')); ?>"><?php echo e(Session::get('success')); ?></p>
      <?php endif; ?>
      <div class="row">
          <div class="col-lg-12">
              <div class="sparkline13-list shadow-reset">
                  <div class="sparkline13-hd">
                      <div class="main-sparkline13-hd">
                          <h1 style="font-weight: bold;">Tổng Lương <i class="fa big-icon fa-user"></i></h1>
                          <div class="sparkline13-outline-icon">
                              <span class="sparkline13-collapse-link"><i class="fa fa-chevron-up"></i></span>
                              <span><i class="fa fa-wrench"></i></span>
                              <span class="sparkline13-collapse-close"><i class="fa fa-times"></i></span>
                          </div>
                      </div>
                  </div>
                  <div class="sparkline13-graph">
                      <div class="datatable-dashv1-list custom-datatable-overright">
                          <div id="toolbar">
                          </div>
                          <table id="table" data-toggle="table" data-pagination="true" data-search="true" data-show-columns="true" data-show-pagination-switch="true" data-show-refresh="true" data-key-events="true" data-show-toggle="true" data-resizable="true" data-cookie="true" data-cookie-id-table="saveId" data-show-export="true" data-click-to-select="true" data-toolbar="#toolbar">
                              <thead>
                                  <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Lương/ngày</th>
                                    <th>Số ngày đi làm</th>
                                    <th>tổng Lương</>
                                  </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                    	<td><?php echo e($employee->employee_code); ?></td>
                                        <td><?php echo e($employee->name); ?></td>
                                        <td><?php echo e(number_format($employee->Position->salary->luongnhan)); ?>.vnđ</td>
                                        <td><?php echo e($total); ?></td>
                                        <td> <?php echo e(number_format(($employee->Position->salary->luongnhan)*($total))); ?>.vnđ</td>
                                    </tr>
                                   	
                                  </tbody>
                          </table>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php echo $__env->make('admin.shared.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DoAn\resources\views/admin/management/tinhluong.blade.php ENDPATH**/ ?>